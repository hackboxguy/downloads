This is the instrction for overwriting oem-firwmare of a5-v11-router with opensource openwrt-firmware.
Steps:
1)on a windows machine, unzip a5-v11-openwrt.zip to a usb-pen-drive
2)insert the usb-pen-drive to the usb port of a5-v11-router.
3)Connect CAT-5 network cable between a5-v11-router and your windows(or linux) desktop.
4)power ON +5v supply to a5-v11-router.
5)red LED on a5-v11-router glows for few seconds, then LED stars blinking between red and blue.
6)
